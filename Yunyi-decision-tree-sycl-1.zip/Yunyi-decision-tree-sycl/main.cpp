// main.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <chrono>
#include <random>
#include <thread>
#include <mutex>

#include <CL/sycl.hpp>
#include "DecisionNode.h"

using namespace cl::sycl;

class RandomForest {
private:
    int n_trees_;
    std::vector<DecisionNode*> trees_;

public:
    RandomForest(int n_trees) : n_trees_(n_trees) {}

    // Unparallelized version of the train function
    void train_serial(std::vector<DataPoint> dataset) {
        int subset_size = dataset.size() / n_trees_;
        for (int i = 0; i < n_trees_; i++) {
            std::vector<DataPoint> subset(dataset.begin() + i*subset_size, dataset.begin() + (i+1)*subset_size);
            DecisionNode* tree = new DecisionNode(subset);
            trees_.push_back(tree);
        }
    }

    // Parallelized version of the train function
    void train(std::vector<DataPoint> dataset) {
        // Randomly shuffle the dataset
        std::random_shuffle(dataset.begin(), dataset.end());

        int subset_size = dataset.size() / n_trees_;
        std::vector<std::thread> threads;
        std::mutex trees_mutex;

        for (int i = 0; i < n_trees_; i++) {
            threads.push_back(std::thread([&, i](){
                std::vector<DataPoint> subset(dataset.begin() + i*subset_size, dataset.begin() + (i+1)*subset_size);
                DecisionNode* tree = new DecisionNode(subset);

                // Lock the trees_ vector for thread-safe access
                trees_mutex.lock();
                trees_.push_back(tree);
                trees_mutex.unlock();
            }));
        }

        // Join all threads to make sure all trees are trained before proceeding
        for (auto& t : threads) {
            t.join();
        }
    }

    // Unparallelized version of the predict function
    int predict_serial(const std::vector<float>& features) const {
        std::map<int, int> class_counts;

        for (const auto& tree : trees_) {
            int prediction = tree->predict(features);
            class_counts[prediction]++;
        }

        int max_count = 0;
        int most_common_class = -1;

        for (const auto& class_count : class_counts) {
            if (class_count.second > max_count) {
                max_count = class_count.second;
                most_common_class = class_count.first;
            }
        }

        return most_common_class;
    }

    // Parallelized version of the predict function
    int predict(const std::vector<float>& features) const {
        std::map<int, int> class_counts;
        std::mutex class_counts_mutex;
        std::vector<std::thread> threads;

        for (const auto& tree : trees_) {
            threads.push_back(std::thread([&](){
                int prediction = tree->predict(features);
                class_counts_mutex.lock();
                class_counts[prediction]++;
                class_counts_mutex.unlock();
            }));
        }

        for (auto& t : threads) {
            t.join();
        }

        int max_count = 0;
        int most_common_class = -1;

        for (const auto& class_count : class_counts) {
            if (class_count.second > max_count) {
                max_count = class_count.second;
                most_common_class = class_count.first;
            }
        }

        return most_common_class;
    }

    ~RandomForest() {
        for (auto tree : trees_) {
            delete tree;
        }
    }
};


std::vector<DataPoint> read_csv(const std::string& file_path) {
    std::ifstream file(file_path);
    std::vector<DataPoint> dataset;
    std::string line;

    if (file.is_open()) {
        while (std::getline(file, line)) {
            std::stringstream line_stream(line);
            std::string cell;
            DataPoint data;
            for (size_t i = 0; i < 4; ++i) {
                std::getline(line_stream, cell, ',');
                data.features.push_back(std::stof(cell));  // Change stoi to stof
            }
            std::getline(line_stream, cell, ',');
            data.label = std::stoi(cell);
            dataset.push_back(data);
        }
        file.close();
    } else {
        std::cerr << "Unable to open file: " << file_path << std::endl;
    }

    return dataset;
}

std::vector<std::vector<int>> init_confusion_matrix(int num_classes) {
    std::vector<std::vector<int>> confusion_matrix(num_classes, std::vector<int>(num_classes, 0));
    return confusion_matrix;
}

void update_confusion_matrix(std::vector<std::vector<int>>& confusion_matrix, int actual, int predicted) {
    confusion_matrix[actual][predicted]++;
}

void print_confusion_matrix(const std::vector<std::vector<int>>& confusion_matrix) {
    for (const auto& row : confusion_matrix) {
        for (const auto& cell : row) {
            std::cout << cell << " ";
        }
        std::cout << std::endl;
    }
}

// Forward declare the kernel name
namespace kernels {
    class simple_sycl_kernel;
}

void train_and_evaluate(std::vector<DataPoint> balanced_dataset_copy, int num_bins, int tree_size, std::vector<float> feature_mins, std::vector<float> feature_maxs, std::string mode) {

        int num_features = balanced_dataset_copy[0].features.size();

        // make a copy of dataset
        // Scale and discretize each feature to the range [0, num_bins-1]
        for (auto& data : balanced_dataset_copy) {
            
            for (size_t i = 0; i < num_features; i++) {
                float scaled_feature = (data.features[i] - feature_mins[i]) / (feature_maxs[i] - feature_mins[i]) * (num_bins - 1);
                data.features[i] = std::round(scaled_feature);
            }
        }

        // // print the first five rows of the dataset
        // std::cout << "The first five rows of the dataset:" << std::endl;
        // for (size_t i = 0; i < 5; i++) {
        //     std::cout << "features: ";
        //     for (size_t j = 0; j < num_features; j++) {
        //         std::cout << dataset[i].features[j] << " ";
        //     }
        //     std::cout << "label: " << dataset[i].label << std::endl;
        // }

        // split the dataset into train and test
        std::vector<DataPoint> train_dataset;
        std::vector<DataPoint> test_dataset;
        // make sure train set have 80% of 1 and 0 in balanced_dataset_copy
        int count_1 = 0;
        int count_0 = 0;
        for (const auto& data : balanced_dataset_copy) {
            if (data.label == 1) {
                count_1++;
            } else if (data.label == 0) {
                count_0++;
            }
        }
        // std::cout << "count_1: " << count_1 << std::endl;
        // std::cout << "count_0: " << count_0 << std::endl;
        int count_1_train = 0;
        int count_0_train = 0;
        for (const auto& data : balanced_dataset_copy) {
            if (data.label == 1 && count_1_train < count_1 * 0.8) {
                train_dataset.push_back(data);
                count_1_train++;
            } else if (data.label == 0 && count_0_train < count_0 * 0.8) {
                train_dataset.push_back(data);
                count_0_train++;
            } else {
                test_dataset.push_back(data);
            }
        }


        auto start_train_time = std::chrono::high_resolution_clock::now();
        auto end_train_time = std::chrono::high_resolution_clock::now();
        auto start_pred_time = std::chrono::high_resolution_clock::now();
        auto end_pred_time = std::chrono::high_resolution_clock::now();
        int num_classes = 2; // Assuming a binary classification problem
        std::vector<std::vector<int>> confusion_matrix = init_confusion_matrix(num_classes);

        if (mode == "parallel") {
            // Start training timer
            start_train_time = std::chrono::high_resolution_clock::now();
            RandomForest forest(tree_size);
            forest.train(train_dataset);
            // Stop training timer
            end_train_time = std::chrono::high_resolution_clock::now();

            // Initialize confusion matrix
            

            // Start prediction timer
            start_pred_time = std::chrono::high_resolution_clock::now();

            for (const auto& data : test_dataset) {
                
                int prediction = forest.predict_serial(data.features);
                update_confusion_matrix(confusion_matrix, data.label, prediction);
            }

            // Stop prediction timer
            end_pred_time = std::chrono::high_resolution_clock::now();
        } else {
            // Start training timer
            start_train_time = std::chrono::high_resolution_clock::now();
            RandomForest forest(tree_size);
            forest.train_serial(train_dataset);
            end_train_time = std::chrono::high_resolution_clock::now();
            // Initialize confusion matrix
            // Start prediction timer
            start_pred_time = std::chrono::high_resolution_clock::now();

            for (const auto& data : test_dataset) {
                int prediction = forest.predict_serial(data.features);
                update_confusion_matrix(confusion_matrix, data.label, prediction);
            }

            // Stop prediction timer
            end_pred_time = std::chrono::high_resolution_clock::now();
        }
        
        // DecisionNode forest(train_dataset);

        

        // Calculate durations
        auto train_duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_train_time - start_train_time);
        auto pred_duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_pred_time - start_pred_time);
        auto total_duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_pred_time - start_train_time);


        // Display running times
        std::cout << "Training time: " << train_duration.count() << " ms" << std::endl;
        std::cout << "Prediction time: " << pred_duration.count() << " ms" << std::endl;
        std::cout << "Total running time: " << total_duration.count() << " ms" << std::endl;

        // Display confusion matrix
        std::cout << "Confusion matrix:" << std::endl;
        for (const auto& row : confusion_matrix) {
            for (const auto& value : row) {
                std::cout << value << ' ';
            }
            std::cout << std::endl;
        }
        // print confusion matrix metrics
        int tp = confusion_matrix[0][0];
        int tn = confusion_matrix[1][1];
        int fp = confusion_matrix[1][0];
        int fn = confusion_matrix[0][1];
        float accuracy = (float)(tp + tn) / (tp + tn + fp + fn);
        std::cout << "accuracy: " << accuracy << std::endl;
        float precision = (float)tp / (tp + fp);
        std::cout << "precision: " << precision << std::endl;
        float recall = (float)tp / (tp + fn);
        std::cout << "recall: " << recall << std::endl;
        float f1 = 2 * precision * recall / (precision + recall);
        std::cout << "f1: " << f1 << std::endl << std::endl;
}

int main() {
    try {
        
        // // Use sycl::cpu_selector to select a CPU device explicitly
        sycl::cpu_selector selector;
        queue q(selector);
        std::cout << "Running on "
                  << q.get_device().get_info<info::device::name>()
                  << std::endl;

        // // A simple SYCL kernel example
        // constexpr size_t dataSize = 1024;
        // std::vector<int> data(dataSize, 0);

        // buffer<int, 1> dataBuffer(data.data(), range<1>(dataSize));

        // q.submit([&](handler &cgh) {
        //     auto accessor = dataBuffer.get_access<access::mode::read_write>(cgh);

        //     cgh.parallel_for<class simple_sycl_kernel>(range<1>(dataSize), [=](id<1> idx) {
        //         accessor[idx] = idx[0];
        //     });
        // });

        // Decision tree example
        std::vector<DataPoint> dataset1 = read_csv("/media/yunyi/Data/Workspace/ruxuproj/Yunyi-decision-tree-sycl/dataset_for_PYNQ_with_trim.csv");
        std::vector<DataPoint> dataset2 = read_csv("/media/yunyi/Data/Workspace/ruxuproj/Yunyi-decision-tree-sycl/dataset_for_PYNQ_with_trim_p2.csv");
        // union the two datasets
        std::vector<DataPoint> dataset = dataset1;
        dataset.insert(dataset.end(), dataset2.begin(), dataset2.end());

        // calculate how many rows in the dataset
        size_t num_rows = dataset.size();
        std::cout << "num_rows: " << num_rows << std::endl;


        // convert label 1 to 0, label 0 to 1
        for (auto& data : dataset) {
            if (data.label == 1) {
                data.label = 0;
            } else if (data.label == 0) {
                data.label = 1;
            } else {
                std::cerr << "Invalid label: " << data.label << std::endl;
            }   
        }

        // make the dataset a histogram, map the float numbers to int numbers from (0, histogram_size - 1)
        size_t num_features = dataset[0].features.size();


        std::vector<int> num_bins_ = {128, 256, 512, 1024, 2048, 4096, 8192, 16384};


        // shuffle the dataset 
        std::random_device rd;
        std::mt19937 g(rd());
        std::shuffle(dataset.begin(), dataset.end(), g);

        // find the first 98907 rows of data whose label is 1
        std::vector<DataPoint> balanced_dataset;
        int count = 0;
        for (const auto& data : dataset) {
            if (data.label == 1) {
                balanced_dataset.push_back(data);
                count++;
            }
            if (count == 98907 * 10) {  // watch out if 1 and 0 are interchanged
                break;
            }
        }
        // find the first 98907 rows of data whose label is 0
        count = 0;
        for (const auto& data : dataset) {
            if (data.label == 0) {
                balanced_dataset.push_back(data);
                count++;
            }
            if (count == 98907) {
                break;
            }
        }

        // reproduce the label 0 data 9 times
        for (int i = 0; i < 9; i++) {
            for (const auto& data : dataset) {
                if (data.label == 0) {
                    balanced_dataset.push_back(data);
                }
            }
        }

        // Define a function to get the threshold indices for 1% and 99%
        auto get_threshold_indices = [](size_t size) {
            size_t lower_idx = size / 100;
            size_t upper_idx = size * 99 / 100;
            return std::make_pair(lower_idx, upper_idx);
        };

        // Exclude the highest 1% and lowest 1% of feature values for each feature
        for (size_t feature_idx = 0; feature_idx < num_features; ++feature_idx) {
            // Collect all the values for the current feature
            std::vector<float> feature_values;
            for (const auto& data : balanced_dataset) {
                feature_values.push_back(data.features[feature_idx]);
            }
            
            // Sort the feature values
            std::sort(feature_values.begin(), feature_values.end());

            // Determine the 1% and 99% percentiles
            auto [lower_idx, upper_idx] = get_threshold_indices(feature_values.size());
            float lower_threshold = feature_values[lower_idx];
            float upper_threshold = feature_values[upper_idx];

            // Filter the dataset to exclude values below 1% and above 99%
            balanced_dataset.erase(std::remove_if(balanced_dataset.begin(), balanced_dataset.end(),
                [feature_idx, lower_threshold, upper_threshold](const DataPoint& data) {
                    return data.features[feature_idx] < lower_threshold || data.features[feature_idx] > upper_threshold;
                }), balanced_dataset.end());
        }

        std::vector<float> feature_mins(num_features, std::numeric_limits<float>::max());
        std::vector<float> feature_maxs(num_features, std::numeric_limits<float>::lowest());

        // Find the min and max for each feature across the entire dataset
        for (const auto& data : balanced_dataset) {
            for (size_t i = 0; i < num_features; i++) {
                feature_mins[i] = std::min(feature_mins[i], data.features[i]);
                feature_maxs[i] = std::max(feature_maxs[i], data.features[i]);
            }
        }

        std::shuffle(balanced_dataset.begin(), balanced_dataset.end(), g);
        std::shuffle(balanced_dataset.begin(), balanced_dataset.end(), g);

        std::vector<DataPoint> balanced_dataset_copy = balanced_dataset; 

        // integrate above four loops into one double-for loop
        std::vector<int> tree_sizes = {1, 10, 100, 1000};
        for (size_t i = 0; i < tree_sizes.size(); i ++) {
            std::cout << "------------------------" << std::endl;
            std::cout << "------------------------" << std::endl;
            std::cout << tree_sizes[i] << " trees" << std::endl;
            for (size_t m = 0; m < num_bins_.size(); m ++) {
                std::cout << "num_bins = " << num_bins_[m] << std::endl;
                train_and_evaluate(balanced_dataset_copy, num_bins_[m], tree_sizes[i], feature_mins, feature_maxs, "parallel");
            }
        }



        } catch (const exception &e) {
            std::cerr << "SYCL exception caught: " << e.what() << std::endl;
            return 1;
        }
    return 0;
}

