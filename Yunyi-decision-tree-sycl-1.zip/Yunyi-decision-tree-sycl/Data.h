// Data.h
#pragma once
#include <vector>

struct DataPoint {
    std::vector<float> features;
    int label;
};
